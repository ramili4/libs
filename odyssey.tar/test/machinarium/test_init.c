
#include <machinarium.h>
#include <odyssey_test.h>

void machinarium_test_init(void)
{
	machinarium_init();
	machinarium_free();
}

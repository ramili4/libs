## #Odyssey test suite

  ####Build and run instructions

    Before you continue reading,
  please see and follow[odyssey build instructions](../ README.md #Build -
                                                    instructions)
      .

    To run you will need
  : *postgresql

```sh cd test./
    odyssey_test
```

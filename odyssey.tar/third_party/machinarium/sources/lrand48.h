#ifndef MM_LRAND48_H
#define MM_LRAND48_H

/*
 * machinarium.
 *
 * cooperative multitasking engine.
 */

void mm_lrand48_seed(void);

#endif /* MM_LRAND48_H */

#ifndef MM_BIND_H
#define MM_BIND_H

/*
 * machinarium.
 *
 * cooperative multitasking engine.
 */

#define MM_BINDWITH_SO_REUSEPORT 1 << 1
#define MM_BINDWITH_SO_REUSEADDR 1 << 2

#endif /* MM_BINDmachine_bind_H */

#ifndef MM_EPOLL_H
#define MM_EPOLL_H

/*
 * machinarium.
 *
 * cooperative multitasking engine.
 */

extern mm_pollif_t mm_epoll_if;

#endif /* MM_EPOLL_H */

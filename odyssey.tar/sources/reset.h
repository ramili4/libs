#ifndef ODYSSEY_RESET_H
#define ODYSSEY_RESET_H

/*
 * Odyssey.
 *
 * Scalable PostgreSQL connection pooler.
 */

int od_reset(od_server_t *);

#endif /* ODYSSEY_RESET_H */

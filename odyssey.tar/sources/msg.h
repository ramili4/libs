#ifndef ODYSSEY_MSG_H
#define ODYSSEY_MSG_H

/*
 * Odyssey.
 *
 * Scalable PostgreSQL connection pooler.
 */

typedef enum { OD_MSG_STAT, OD_MSG_CLIENT_NEW, OD_MSG_LOG } od_msg_t;

#endif /* ODYSSEY_MSG_H */

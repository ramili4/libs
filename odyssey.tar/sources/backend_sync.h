#ifndef ODYSSEY_BACKEND_SYNC_H
#define ODYSSEY_BACKEND_SYNC_H

/*
 * Odyssey.
 *
 * Scalable PostgreSQL connection pooler.
 */

int od_backend_request_sync_point(od_server_t *);

#endif /* ODYSSEY_BACKEND_SYNC_H */

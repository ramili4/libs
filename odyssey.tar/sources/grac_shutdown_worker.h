#ifndef ODYSSEY_GRAC_KILLER_H
#define ODYSSEY_GRAC_KILLER_H

/*
 * Odyssey.
 *
 * Scalable PostgreSQL connection pooler.
 */

void od_grac_shutdown_worker(void *arg);

#endif /* ODYSSEY_GRAC_KILLER_H */

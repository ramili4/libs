#ifndef ODYSSEY_PSTMT_H
#define ODYSSEY_PSTMT_H

/*
 * Odyssey.
 *
 * Scalable PostgreSQL connection pooler.
 */

#endif /* ODYSSEY_PSTMT_H */


#ifndef ODYSSEY_COMMON_CONST_H
#define ODYSSEY_COMMON_CONST_H

#define OD_QRY_MAX_SZ 512 /* odyssey maximum allowed query size */

#endif // ODYSSEY_COMMON_CONST_H

#ifndef ODYSSEY_SASL_H
#define ODYSSEY_SASL_H

typedef enum {
	OD_SASL_ERROR_AUTH_IDENTITY = -4,
	OD_SASL_ERROR_MANDATORY_EXT = -5,
} od_sasl_error_t;

#endif /* ODYSSEY_SASL_H */
#ifndef ODYSSEY_DEPLOY_H
#define ODYSSEY_DEPLOY_H

/*
 * Odyssey.
 *
 * Scalable PostgreSQL connection pooler.
 */

#include "common_const.h"

int od_deploy(od_client_t *, char *);

#endif /* ODYSSEY_DEPLOY_H */

#!/bin/bash

/run-clang-format/run-clang-format.py -r --clang-format-executable clang-format-18 $@